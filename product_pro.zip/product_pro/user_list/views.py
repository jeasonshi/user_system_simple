from django.http import HttpResponse
from django.shortcuts import render, redirect

# Create your views here.
from duct_list.models import Productlist
from user_list.models import Userlist


def denglu(request):
    return render(request, 'login/newdenglu.html')

def dodenglu(request):
    username = request.GET.get('username')
    password = request.GET.get('password')
    if username=='root' and password=='root':
        return render(request,'super_user/super_user.html')
    else:
        userlist=Userlist.objects.filter(username=username)
        if userlist==[] or len(userlist)==0:
            return render(request,'login/newdenglu.html',context={'msg':'用户名不存在'})
        user=userlist[0]
        if password != user.password:
            return render(request,'login/newdenglu.html',context={'msg':'用户名或密码错误'})
        return redirect('/putong_user/')

        #request.session['user'] = {'username': user.username, 'password': user.password, 'email': user.email}
            #请求服务器设置 session 缓存 并保存信息用于其他页面的共享信息 其他页面 获取值的方式 是{{request.session.名称}}
        # user=Userlist.objects.all()
        # print(user)
        # check=False
        # for i in user:
        #     c=i.username
        #     d=i.password
        #     print(c)
        #     if username!=c:
        #         print('bucunzai')
        #     elif username==c and password==d:
        #         check=True
        #         print('cunzai ')
        # if check==True:
        #     return redirect('/putong_user/')
        # else:
        #     return redirect('/denglu/')







def user_manage(request):
    u=Userlist.objects.all()
    return render(request,'super_user/user_manage.html',context={'user':u})
def user_delete(request):
    id=request.GET.get('id')
    u=Userlist.objects.get(id=id)
    u.delete()
    return redirect('/user_manage/')
def user_add(request):
    return render(request,'super_user/user_add.html')
def do_user_add(request):
    username=request.GET.get('username')
    password=request.GET.get('password')
    Userlist.objects.create(username=username,password=password)
    return redirect('/user_manage/')
def user_updata(request):
    id = request.GET.get('id')
    u=Userlist.objects.get(id=id)
    return render(request,'super_user/user_updata.html',context={'u':u})
def do_user_updata(request):
    id=request.GET.get('id')
    username = request.GET.get('username')
    password = request.GET.get('password')
    u=Userlist.objects.get(id=id)
    u.username=username
    u.password=password
    u.save()
    return redirect('/user_manage/')
def zhuce(request):
    return render(request,'zhuce/zhuce.html')
def dozhuce(request):
    username=request.GET.get('username')
    password=request.GET.get('password')
    repassword=request.GET.get('repassword')
    if password != repassword:
        return render(request,'zhuce/zhuce.html',context={'msg':'两次密码不一致'})
    userlist = Userlist.objects.filter(username=username)
    if len(userlist) !=0 :
        return render(request,'zhuce/zhuce.html',context={'msg':'该用户名已存在'})
    Userlist.objects.create(username=username,password=password)
    return redirect('/putong_user/')


def putong_user(request):
    list=Productlist.objects.all()
    return render(request,'putong_shouye/putong_shouye.html',context={'list':list})
