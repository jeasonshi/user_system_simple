"""product_pro URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from django.contrib import admin

from user_list import views

urlpatterns = [
    url(r'^denglu/', views.denglu),  # 登录的展示
    url(r'^dodenglu/', views.dodenglu),  # 登录的功能实现
    #超级用户管理普通用户
    url(r'^user_manage/', views.user_manage),
    url(r'^user_delete/', views.user_delete),

    url(r'^user_add/', views.user_add),
    url(r'^do_user_add/', views.do_user_add),


    url(r'^user_updata/', views.user_updata),
    url(r'^do_user_updata', views.do_user_updata),

    url(r'^zhuce/', views.zhuce),  # 注册的展示
    url(r'^dozhuce/', views.dozhuce),  # 注册功能的实现

    url(r'^putong_user/', views.putong_user),  # 普通用户界面








]
