"""product_pro URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from django.contrib import admin

from duct_list import views

urlpatterns = [

    url(r'^shouye/',views.shouye),#展示页面

    url(r'^deletepro/',views.deletepro),#删除功能

    url(r'^addpro/',views.addpro),#添加功能的展示页面
    url(r'^doaddpro/',views.doaddpro),#添加的功能实现

    url(r'^updatepro/',views.updatepro),#修改的展示页面
    url(r'^doupdatepro/',views.doupdatepro),#修改的功能实现



]
