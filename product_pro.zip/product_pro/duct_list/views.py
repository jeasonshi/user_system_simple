from django.http import HttpResponse
from django.shortcuts import render, redirect

# Create your views here.
from duct_list.models import Productlist

def shouye(request):
    list=Productlist.objects.all()
    return render(request,'shouye/shouye.html',context={'list':list})


def deletepro(request):
    id=request.GET.get('id')
    p=Productlist.objects.get(id=id)
    p.delete()
    return redirect('/shouye/')


def addpro(request):
    return render(request,'shouye/addpro.html')


def doaddpro(request):
    name=request.POST.get('name')
    price=request.POST.get('price')
    addr=request.POST.get('addr')
    nation=request.POST.get('nation')
    Productlist.objects.create(name=name,price=price,addr=addr,nation=nation)
    return redirect('/shouye/')


def updatepro(request):
    id=request.GET.get('id')
    p=Productlist.objects.get(id=id)
    return render(request,'shouye/updata.html',context={'p':p})


def doupdatepro(request):
    id=request.POST.get('id')
    name=request.POST.get('name')
    price=request.POST.get('price')
    addr=request.POST.get('addr')
    nation=request.POST.get('nation')
    p=Productlist.objects.get(id=id)
    p.name=name
    p.price=price
    p.addr=addr
    p.nation=nation
    p.save()

    return redirect('/shouye/')

